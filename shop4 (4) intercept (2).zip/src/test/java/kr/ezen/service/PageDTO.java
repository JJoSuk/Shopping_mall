package kr.ezen.service;

public class PageDTO {
}
