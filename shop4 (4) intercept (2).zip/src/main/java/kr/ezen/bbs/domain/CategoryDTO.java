package kr.ezen.bbs.domain;

import lombok.Data;

@Data
public class CategoryDTO {
    private int catNum;
    private String code;
    private String catName;

}
